import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ReadersWriters {

    public static final int NUM_THREADS = 100;
    public static final int NUM_READS = 100;
    private static final String BD_FILE = "bd.txt";
    private static final Random random = new Random();

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java ReadersWriters <numReaders> <numWriters>");
            System.exit(1);
        }

        int numReaders = Integer.parseInt(args[0]);
        int numWriters = Integer.parseInt(args[1]);

        if (numReaders + numWriters != NUM_THREADS) {
            System.err.println("The number of readers and writers must add up to " + NUM_THREADS);
            System.exit(1);
        }

        try {
            List<String> words = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader(BD_FILE))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    words.add(line);
                }
            }

            SharedData sharedData = new SharedData(words);

            List<Thread> threads = new ArrayList<>();
            for (int i = 0; i < numReaders; i++) {
                threads.add(new Reader(i, sharedData, random));
            }

            for (int i = 0; i < numWriters; i++) {
                threads.add(new Writer(i, sharedData));
            }

            for (Thread thread : threads) {
                thread.start();
            }

            for (Thread thread : threads) {
                thread.join();
            }

            long startTime = System.currentTimeMillis();
            sharedData.print();
            sharedData.collectPerformanceData(threads);
            long endTime = System.currentTimeMillis();
            System.out.println("Tempo de execução: " + (endTime - startTime) + "ms");

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class SharedData {
    private final List<String> words;
    private int readersCount;
    private boolean isWriteLocked;

    public SharedData(List<String> words) {
        this.words = words;
        this.readersCount = 0;
        this.isWriteLocked = false;
    }

    public synchronized String read(int index) {
        enterRead();
        String result = words.get(index);
        exitRead();
        return result;
    }

    public synchronized void write(String word, int index) {
        words.set(index, word);
    }

    public synchronized void enterRead() {
        while (isWriteLocked) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        readersCount++;
    }

    public synchronized void exitRead() {
        readersCount--;
        if (readersCount == 0) {
            notifyAll();
        }
    }

    public synchronized void enterWrite() {
        while (readersCount > 0 || isWriteLocked) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        isWriteLocked = true;
    }

    public synchronized void exitWrite() {
        isWriteLocked = false;
        notifyAll();
    }

    public void print() {
        for (String word : words) {
            System.out.println(word);
        }
    }

    public int size() {
        return words.size();
    }

    public void collectPerformanceData(List<Thread> threads) {
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;

        int totalReads = 0;
        int totalWrites = 0;

        long totalBlockingTime = 0;
        for (Thread thread : threads) {
            if (thread instanceof Reader) {
                totalReads += ((Reader) thread).getNumberOfReads();
                totalBlockingTime += ((Reader) thread).getBlockingTime();
            } else if (thread instanceof Writer) {
                totalWrites += ((Writer) thread).getNumberOfWrites();
                totalBlockingTime += ((Writer) thread).getBlockingTime();
            }
        }

        long blockingTime = totalBlockingTime / threads.size();

        
        System.out.println("Total reads: " + totalReads);
        System.out.println("Total writes: " + totalWrites);
        System.out.println("Blocking time: " + blockingTime + " ms");
    }
}

class Reader extends Thread {
    private final int id;
    private final SharedData sharedData;
    private final Random random;
    private int numberOfReads;
    private long blockingTime;

    public Reader(int id, SharedData sharedData, Random random) {
        this.id = id;
        this.sharedData = sharedData;
        this.random = random;
        this.numberOfReads = 0;
        this.blockingTime = 0;
    }

    @Override
    public void run() {
        for (int i = 0; i < ReadersWriters.NUM_READS; i++) {
            int index = random.nextInt(sharedData.size());

            long threadStartTime = System.currentTimeMillis();
            sharedData.enterRead();
            long threadEndTime = System.currentTimeMillis();
            blockingTime += threadEndTime - threadStartTime;

            String word = sharedData.read(index);
            numberOfReads++;

            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            sharedData.exitRead();
        }
    }

    public int getNumberOfReads() {
        return numberOfReads;
    }

    public long getBlockingTime() {
        return blockingTime;
    }
}

class Writer extends Thread {
    private final int id;
    private final SharedData sharedData;
    private int numberOfWrites;
    private long blockingTime;

    public Writer(int id, SharedData sharedData) {
        this.id = id;
        this.sharedData = sharedData;
        this.numberOfWrites = 0;
        this.blockingTime = 0;
    }

    @Override
    public void run() {
        for (int i = 0; i < ReadersWriters.NUM_READS; i++) {
            long threadStartTime = System.currentTimeMillis();
            sharedData.enterWrite();
            long threadEndTime = System.currentTimeMillis();
            blockingTime += threadEndTime - threadStartTime;

            sharedData.write("MODIFICADO", 0);
            numberOfWrites++;

            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            sharedData.exitWrite();
        }
    }

    public int getNumberOfWrites() {
        return numberOfWrites;
    }

    public long getBlockingTime() {
        return blockingTime;
    }
}
