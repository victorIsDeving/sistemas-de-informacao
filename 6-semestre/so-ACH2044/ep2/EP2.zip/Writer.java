public class Writer {
    
}
public class Writer extends Thread {
    private final int id;
    private final SharedData sharedData;

    public Writer(int id, SharedData sharedData) {
        this.id = id;
        this.sharedData = sharedData;
    }

    @Override
    public void run() {
        for (int i = 0; i < ReadersWriters.NUM_READS; i++) {
            sharedData.enterWrite();
            sharedData.write("MODIFICADO", 0);

            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            sharedData.exitWrite();
        }
    }

    public int getNumberOfWrites() {
        return ReadersWriters.NUM_READS;
    }
}
