class Reader extends Thread {
    // ...
    private long blockingTime;

    @Override
    public void run() {
        // ...
        long threadStartTime = System.currentTimeMillis();
        sharedData.enterRead();
        long threadEndTime = System.currentTimeMillis();
        blockingTime += threadEndTime - threadStartTime;

        // ...
    }

    public long getBlockingTime() {
        return blockingTime;
    }
}

class Writer extends Thread {
    // ...
    private long blockingTime;

    @Override
    public void run() {
        // ...
        long threadStartTime = System.currentTimeMillis();
        sharedData.enterWrite();
        long threadEndTime = System.currentTimeMillis();
        blockingTime += threadEndTime - threadStartTime;

        // ...
    }

    public long getBlockingTime() {
        return blockingTime;
    }
}