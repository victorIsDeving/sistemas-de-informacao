contar_correspondencias <- function(row, col1, col2) {
  string1 <- as.character(row[col1])
  string2 <- as.character(row[col2])
  return(sum(strsplit(string1, "")[[1]] == strsplit(string2, "")[[1]]))
}


get_dataset <- function(){
  colunas_desejadas <- c(
    'SG_UF_RESIDENCIA',
    
    'NU_IDADE',
    'IN_TREINEIRO',
    'TP_ESCOLA',
    
    'NU_NOTA_CN',
    'NU_NOTA_CH',
    'NU_NOTA_LC',
    'NU_NOTA_MT',
    'NU_NOTA_REDACAO'
  )
  
  dataset <- data.table::fread(input='./DADOS/MICRODADOS_ENEM_2019.csv',
                               integer64='character',
                               skip=0,  #Ler do inicio
                               nrow=-1, #Ler todos os registros
                               select = colunas_desejadas,
                               na.strings = "",
                               showProgress = TRUE,
                               encoding = 'UTF-8'
  )
  nrow(dataset)
  
  dataset$Regiao <- factor(dataset$SG_UF_RESIDENCIA, 
                           levels = c("AC",    "AL",       "AP",    "AM",    "BA",       "CE",       "DF",           "ES",      "GO",           "MA",       "MT",           "MS",           "MG",      "PA",    "PB",       "PR",  "PE",       "PI",       "RJ",      "RN",       "RS",  "RO",    "RR",    "SC",  "SP",      "SE",       "TO"),
                           labels = c("Norte", "Nordeste", "Norte", "Norte", "Nordeste", "Nordeste", "Centro-Oeste", "Sudeste", "Centro-Oeste", "Nordeste", "Centro-Oeste", "Centro-Oeste", "Sudeste", "Norte", "Nordeste", "Sul", "Nordeste", "Nordeste", "Sudeste", "Nordeste", "Sul", "Norte", "Norte", "Sul", "Sudeste", "Nordeste", "Centro-Oeste"))
  
  
  dataset$TP_ESCOLA <- factor(dataset$TP_ESCOLA, levels = c(1,2,3,4),
                              labels=c('Nao respondeu',
                                       'Publica',
                                       'Privada',
                                       'Exterior'))
  
  dataset <- na.omit(dataset)
  
  dataset$SG_UF_RESIDENCIA <- NULL
  setnames(dataset, 'NU_NOTA_CH', 'Nota Humanas')
  setnames(dataset, 'NU_NOTA_CN', 'Nota Natureza')
  setnames(dataset, 'NU_NOTA_LC', 'Nota Linguagem')
  setnames(dataset, 'NU_NOTA_MT', 'Nota Matematica')
  setnames(dataset, 'NU_IDADE', 'Idade')
  setnames(dataset, 'NU_NOTA_REDACAO', 'Nota Redacao')
  
  return(dataset)
}